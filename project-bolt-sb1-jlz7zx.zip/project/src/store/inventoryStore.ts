import { create } from 'zustand';
import type { Item } from '../types';

interface InventoryState {
  items: Item[];
  addItem: (item: Omit<Item, 'id'>) => void;
  updateItem: (item: Item) => void;
  deleteItem: (id: string) => void;
}

export const useInventoryStore = create<InventoryState>((set) => ({
  items: [
    { id: '1', name: 'Produto 1', price: 100, quantity: 10, description: 'Descrição do produto 1' },
    { id: '2', name: 'Produto 2', price: 200, quantity: 5, description: 'Descrição do produto 2' },
  ],
  addItem: (item) =>
    set((state) => ({
      items: [...state.items, { ...item, id: Date.now().toString() }],
    })),
  updateItem: (updatedItem) =>
    set((state) => ({
      items: state.items.map((item) =>
        item.id === updatedItem.id ? updatedItem : item
      ),
    })),
  deleteItem: (id) =>
    set((state) => ({
      items: state.items.filter((item) => item.id !== id),
    })),
}));