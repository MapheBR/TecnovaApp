import { jsPDF } from 'jspdf';
import type { Budget } from '../types';

export const generateBudgetPDF = (budget: Budget) => {
  const doc = new jsPDF();
  const pageWidth = doc.internal.pageSize.getWidth();
  
  // Header
  doc.setFontSize(20);
  doc.text('TecnovaApp - Orçamento', pageWidth / 2, 20, { align: 'center' });
  
  // Client Info
  doc.setFontSize(12);
  doc.text(`Cliente: ${budget.clientName}`, 20, 40);
  doc.text(`Data: ${new Date(budget.date).toLocaleDateString()}`, 20, 50);
  doc.text(`Orçamento #${budget.id}`, 20, 60);
  
  // Items Table
  const tableStart = 80;
  const columns = ['Item', 'Qtd', 'Preço Unit.', 'Subtotal'];
  const columnWidths = [80, 20, 40, 40];
  let yPosition = tableStart;
  
  // Table Header
  doc.setFont('helvetica', 'bold');
  let xPosition = 20;
  columns.forEach((column, index) => {
    doc.text(column, xPosition, yPosition);
    xPosition += columnWidths[index];
  });
  
  // Table Content
  doc.setFont('helvetica', 'normal');
  budget.items.forEach((item, index) => {
    yPosition += 10;
    
    if (yPosition > 280) {
      doc.addPage();
      yPosition = 20;
    }
    
    xPosition = 20;
    doc.text(item.name, xPosition, yPosition);
    doc.text(item.quantity.toString(), xPosition + columnWidths[0], yPosition);
    doc.text(`R$ ${item.price.toFixed(2)}`, xPosition + columnWidths[0] + columnWidths[1], yPosition);
    doc.text(`R$ ${item.subtotal.toFixed(2)}`, xPosition + columnWidths[0] + columnWidths[1] + columnWidths[2], yPosition);
  });
  
  // Total
  yPosition += 20;
  doc.setFont('helvetica', 'bold');
  doc.text(`Total: R$ ${budget.total.toFixed(2)}`, pageWidth - 30, yPosition, { align: 'right' });
  
  return doc;
};