export interface Item {
  id: string;
  name: string;
  price: number;
  quantity: number;
  description: string;
}

export interface Budget {
  id: string;
  clientName: string;
  items: BudgetItem[];
  total: number;
  date: string;
  status: 'pending' | 'approved' | 'rejected';
}

export interface BudgetItem extends Item {
  quantity: number;
  subtotal: number;
}