import React, { useState } from 'react';
import { BudgetForm } from '../components/Budget/BudgetForm';
import { BudgetPreview } from '../components/Budget/BudgetPreview';
import { useInventoryStore } from '../store/inventoryStore';
import type { Budget, BudgetItem } from '../types';

export function BudgetPage() {
  const items = useInventoryStore((state) => state.items);
  const [currentBudget, setCurrentBudget] = useState<Budget | null>(null);

  const handleBudgetSubmit = (clientName: string, items: BudgetItem[]) => {
    const budget: Budget = {
      id: Date.now().toString(),
      clientName,
      items,
      total: items.reduce((acc, item) => acc + item.subtotal, 0),
      date: new Date().toISOString(),
      status: 'pending'
    };
    setCurrentBudget(budget);
  };

  return (
    <div className="max-w-4xl mx-auto py-6 px-4">
      <h1 className="text-2xl font-bold mb-6">Criar Orçamento</h1>
      <BudgetForm items={items} onSubmit={handleBudgetSubmit} />
      {currentBudget && (
        <BudgetPreview
          budget={currentBudget}
          onClose={() => setCurrentBudget(null)}
        />
      )}
    </div>
  );
}