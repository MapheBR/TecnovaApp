import React, { useState } from 'react';
import { Item } from '../types';
import { InventoryList } from '../components/Inventory/InventoryList';
import { Plus } from 'lucide-react';
import { useInventoryStore } from '../store/inventoryStore';

export function InventoryPage() {
  const { items, addItem, updateItem, deleteItem } = useInventoryStore();
  const [showForm, setShowForm] = useState(false);
  const [formData, setFormData] = useState<Partial<Item>>({});

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (formData.id) {
      updateItem(formData as Item);
    } else {
      addItem(formData as Omit<Item, 'id'>);
    }
    setShowForm(false);
    setFormData({});
  };

  return (
    <div className="max-w-4xl mx-auto py-6 px-4">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold">Gerenciar Inventário</h1>
        <button
          onClick={() => setShowForm(true)}
          className="bg-primary text-white px-4 py-2 rounded-lg flex items-center"
        >
          <Plus className="h-5 w-5 mr-2" />
          Novo Item
        </button>
      </div>

      {showForm && (
        <div className="bg-white rounded-lg shadow-md p-6 mb-6">
          <h2 className="text-xl font-semibold mb-4">
            {formData.id ? 'Editar Item' : 'Novo Item'}
          </h2>
          <form onSubmit={handleSubmit}>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Nome
                </label>
                <input
                  type="text"
                  value={formData.name || ''}
                  onChange={e => setFormData({ ...formData, name: e.target.value })}
                  className="w-full p-2 border rounded focus:border-primary focus:ring-1 focus:ring-primary"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Preço
                </label>
                <input
                  type="number"
                  value={formData.price || ''}
                  onChange={e => setFormData({ ...formData, price: Number(e.target.value) })}
                  className="w-full p-2 border rounded focus:border-primary focus:ring-1 focus:ring-primary"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Quantidade
                </label>
                <input
                  type="number"
                  value={formData.quantity || ''}
                  onChange={e => setFormData({ ...formData, quantity: Number(e.target.value) })}
                  className="w-full p-2 border rounded focus:border-primary focus:ring-1 focus:ring-primary"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Descrição
                </label>
                <textarea
                  value={formData.description || ''}
                  onChange={e => setFormData({ ...formData, description: e.target.value })}
                  className="w-full p-2 border rounded focus:border-primary focus:ring-1 focus:ring-primary"
                  required
                />
              </div>
            </div>
            <div className="flex justify-end mt-4 space-x-2">
              <button
                type="button"
                onClick={() => {
                  setShowForm(false);
                  setFormData({});
                }}
                className="px-4 py-2 border rounded text-gray-600 hover:bg-gray-50"
              >
                Cancelar
              </button>
              <button
                type="submit"
                className="px-4 py-2 bg-primary text-white rounded hover:bg-primary-dark"
              >
                {formData.id ? 'Atualizar' : 'Criar'}
              </button>
            </div>
          </form>
        </div>
      )}

      <InventoryList
        items={items}
        onEdit={(item) => {
          setFormData(item);
          setShowForm(true);
        }}
        onDelete={deleteItem}
      />
    </div>
  );
}