import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Clipboard, Package } from 'lucide-react';

export function HomePage() {
  const navigate = useNavigate();

  return (
    <div className="max-w-4xl mx-auto py-12 px-4">
      <h1 className="text-3xl font-bold text-center mb-12">Bem-vindo ao TecnovaApp</h1>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div 
          onClick={() => navigate('/inventory')}
          className="bg-white p-8 rounded-lg shadow-md cursor-pointer hover:shadow-lg transition-shadow"
        >
          <div className="flex flex-col items-center text-center">
            <Package className="h-16 w-16 text-primary mb-4" />
            <h2 className="text-xl font-semibold mb-2">Gerenciar Inventário</h2>
            <p className="text-gray-600">
              Cadastre e gerencie seus produtos no estoque
            </p>
          </div>
        </div>

        <div 
          onClick={() => navigate('/budget')}
          className="bg-white p-8 rounded-lg shadow-md cursor-pointer hover:shadow-lg transition-shadow"
        >
          <div className="flex flex-col items-center text-center">
            <Clipboard className="h-16 w-16 text-primary mb-4" />
            <h2 className="text-xl font-semibold mb-2">Criar Orçamento</h2>
            <p className="text-gray-600">
              Crie orçamentos para seus clientes
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}