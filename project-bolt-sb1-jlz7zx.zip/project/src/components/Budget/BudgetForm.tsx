import React, { useState } from 'react';
import { FileText, Plus, Minus } from 'lucide-react';
import type { Item, BudgetItem } from '../../types';

interface BudgetFormProps {
  items: Item[];
  onSubmit: (clientName: string, items: BudgetItem[]) => void;
}

export function BudgetForm({ items, onSubmit }: BudgetFormProps) {
  const [clientName, setClientName] = useState('');
  const [selectedItems, setSelectedItems] = useState<BudgetItem[]>([]);
  const [selectedItemId, setSelectedItemId] = useState('');

  const handleAddItem = () => {
    const item = items.find(i => i.id === selectedItemId);
    if (!item) return;

    const existingItem = selectedItems.find(i => i.id === item.id);
    if (existingItem) {
      setSelectedItems(selectedItems.map(i => 
        i.id === item.id 
          ? { ...i, quantity: i.quantity + 1, subtotal: (i.quantity + 1) * i.price }
          : i
      ));
    } else {
      const budgetItem: BudgetItem = {
        ...item,
        quantity: 1,
        subtotal: item.price
      };
      setSelectedItems([...selectedItems, budgetItem]);
    }
    setSelectedItemId('');
  };

  const handleUpdateQuantity = (itemId: string, newQuantity: number) => {
    if (newQuantity < 1) return;
    setSelectedItems(selectedItems.map(item =>
      item.id === itemId
        ? { ...item, quantity: newQuantity, subtotal: newQuantity * item.price }
        : item
    ));
  };

  const handleRemoveItem = (itemId: string) => {
    setSelectedItems(selectedItems.filter(item => item.id !== itemId));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (selectedItems.length === 0) return;
    onSubmit(clientName, selectedItems);
    setClientName('');
    setSelectedItems([]);
    setSelectedItemId('');
  };

  const total = selectedItems.reduce((acc, item) => acc + item.subtotal, 0);

  return (
    <div className="bg-white rounded-lg shadow p-6">
      <div className="flex items-center mb-6">
        <FileText className="h-6 w-6 text-primary mr-2" />
        <h2 className="text-xl font-semibold">Novo Orçamento</h2>
      </div>
      
      <form onSubmit={handleSubmit}>
        <div className="mb-4">
          <label className="block text-gray-700 mb-2">Nome do Cliente</label>
          <input
            type="text"
            value={clientName}
            onChange={(e) => setClientName(e.target.value)}
            className="w-full p-2 border rounded focus:border-primary focus:ring-1 focus:ring-primary"
            required
          />
        </div>

        <div className="mb-4">
          <label className="block text-gray-700 mb-2">Adicionar Items</label>
          <div className="flex space-x-2">
            <select
              value={selectedItemId}
              className="flex-1 p-2 border rounded focus:border-primary focus:ring-1 focus:ring-primary"
              onChange={(e) => setSelectedItemId(e.target.value)}
            >
              <option value="">Selecione um item...</option>
              {items.map(item => (
                <option key={item.id} value={item.id}>
                  {item.name} - R$ {item.price.toFixed(2)}
                </option>
              ))}
            </select>
            <button
              type="button"
              onClick={handleAddItem}
              disabled={!selectedItemId}
              className="bg-primary text-white px-4 py-2 rounded hover:bg-primary-dark disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <Plus className="h-5 w-5" />
            </button>
          </div>
        </div>

        <div className="mb-6">
          <h3 className="text-lg font-semibold mb-2">Items Selecionados</h3>
          {selectedItems.length === 0 ? (
            <p className="text-gray-500 text-center py-4">Nenhum item selecionado</p>
          ) : (
            <div className="border rounded-lg overflow-hidden">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-4 py-2 text-left">Item</th>
                    <th className="px-4 py-2 text-left">Quantidade</th>
                    <th className="px-4 py-2 text-left">Preço Unit.</th>
                    <th className="px-4 py-2 text-left">Subtotal</th>
                    <th className="px-4 py-2"></th>
                  </tr>
                </thead>
                <tbody>
                  {selectedItems.map((item) => (
                    <tr key={`selected-${item.id}`} className="border-b">
                      <td className="px-4 py-2">{item.name}</td>
                      <td className="px-4 py-2">
                        <div className="flex items-center space-x-2">
                          <button
                            type="button"
                            onClick={() => handleUpdateQuantity(item.id, item.quantity - 1)}
                            className="text-gray-500 hover:text-primary"
                          >
                            <Minus className="h-4 w-4" />
                          </button>
                          <span>{item.quantity}</span>
                          <button
                            type="button"
                            onClick={() => handleUpdateQuantity(item.id, item.quantity + 1)}
                            className="text-gray-500 hover:text-primary"
                          >
                            <Plus className="h-4 w-4" />
                          </button>
                        </div>
                      </td>
                      <td className="px-4 py-2">R$ {item.price.toFixed(2)}</td>
                      <td className="px-4 py-2">R$ {item.subtotal.toFixed(2)}</td>
                      <td className="px-4 py-2">
                        <button
                          type="button"
                          onClick={() => handleRemoveItem(item.id)}
                          className="text-red-500 hover:text-red-700"
                        >
                          <Minus className="h-4 w-4" />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
          <div className="mt-4 text-right">
            <strong>Total: R$ {total.toFixed(2)}</strong>
          </div>
        </div>

        <button
          type="submit"
          disabled={selectedItems.length === 0 || !clientName}
          className="w-full bg-primary text-white py-2 px-4 rounded hover:bg-primary-dark disabled:opacity-50 disabled:cursor-not-allowed"
        >
          Criar Orçamento
        </button>
      </form>
    </div>
  );
}