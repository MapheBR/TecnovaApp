import React from 'react';
import { FileText, Download } from 'lucide-react';
import type { Budget } from '../../types';
import { generateBudgetPDF } from '../../utils/pdfGenerator';

interface BudgetPreviewProps {
  budget: Budget;
  onClose: () => void;
}

export function BudgetPreview({ budget, onClose }: BudgetPreviewProps) {
  const handleDownloadPDF = () => {
    const doc = generateBudgetPDF(budget);
    doc.save(`orcamento-${budget.id}.pdf`);
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-lg shadow-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
        <div className="p-6">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center">
              <FileText className="h-6 w-6 text-primary mr-2" />
              <h2 className="text-2xl font-semibold">Orçamento</h2>
            </div>
            <button
              onClick={handleDownloadPDF}
              className="flex items-center bg-primary text-white px-4 py-2 rounded hover:bg-primary-dark"
            >
              <Download className="h-5 w-5 mr-2" />
              Baixar PDF
            </button>
          </div>

          <div className="mb-6">
            <h3 className="font-semibold mb-2">Informações do Cliente</h3>
            <p>Nome: {budget.clientName}</p>
            <p>Data: {new Date(budget.date).toLocaleDateString()}</p>
          </div>

          <div className="mb-6">
            <h3 className="font-semibold mb-4">Itens</h3>
            <div className="border rounded-lg overflow-hidden">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Item</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Qtd</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Preço Unit.</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Subtotal</th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {budget.items.map((item) => (
                    <tr key={item.id}>
                      <td className="px-6 py-4 whitespace-nowrap">{item.name}</td>
                      <td className="px-6 py-4 whitespace-nowrap">{item.quantity}</td>
                      <td className="px-6 py-4 whitespace-nowrap">R$ {item.price.toFixed(2)}</td>
                      <td className="px-6 py-4 whitespace-nowrap">R$ {item.subtotal.toFixed(2)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          <div className="flex justify-between items-center mt-6">
            <button
              onClick={onClose}
              className="px-4 py-2 border rounded text-gray-600 hover:bg-gray-50"
            >
              Fechar
            </button>
            <div className="text-xl font-bold">
              Total: R$ {budget.total.toFixed(2)}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}