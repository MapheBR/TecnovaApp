import React from 'react';
import { Menu, Home } from 'lucide-react';
import { Link } from 'react-router-dom';

export function Header() {
  return (
    <header className="bg-white shadow-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center">
            <Link to="/" className="text-primary font-bold text-xl flex items-center">
              <Home className="h-6 w-6 mr-2" />
              TecnovaApp
            </Link>
          </div>
          <nav className="hidden md:flex space-x-8">
            <Link to="/inventory" className="text-gray-700 hover:text-primary">
              Inventário
            </Link>
            <Link to="/budget" className="text-gray-700 hover:text-primary">
              Orçamentos
            </Link>
          </nav>
          <div className="md:hidden">
            <Menu className="h-6 w-6 text-gray-700" />
          </div>
        </div>
      </div>
    </header>
  );
}