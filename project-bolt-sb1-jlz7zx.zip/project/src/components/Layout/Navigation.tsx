import React, { createContext, useContext, ReactNode } from 'react';

type NavigationContextType = {
  navigate: (path: string) => void;
};

const NavigationContext = createContext<NavigationContextType>({ navigate: () => {} });

export const useNavigate = () => {
  const context = useContext(NavigationContext);
  return context.navigate;
};

export function NavigationProvider({ children }: { children: ReactNode }) {
  const navigate = (path: string) => {
    // Handle navigation state here
    console.log(`Navigating to: ${path}`);
  };

  return (
    <NavigationContext.Provider value={{ navigate }}>
      {children}
    </NavigationContext.Provider>
  );
}